\$debug\_tpl {#variable.debug_template}
============

This is the name of the template file used for the debugging console. By
default, it is named `debug.tpl` and is located in the
[`SMARTY_DIR`](#constant.smarty.dir).

See also [`$debugging`](#variable.debugging) and the [debugging
console](#chapter.debugging.console) section.
